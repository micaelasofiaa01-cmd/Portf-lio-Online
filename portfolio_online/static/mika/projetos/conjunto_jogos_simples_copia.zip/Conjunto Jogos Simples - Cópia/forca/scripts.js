const palavras = ["javascript", "computador", "programa", "desenvolvedor", "teclado"];
let palavra = palavras[Math.floor(Math.random() * palavras.length)];
let palavraCorreta = Array(palavra.length).fill("_");
let erros = 0;
const maxErros = 6;

const palavraDisplay = document.getElementById("palavraDisplay");
const letrasDiv = document.querySelector(".letras");
const mensagem = document.getElementById("mensagem");
const canvas = document.getElementById("forcaCanvas");
const ctx = canvas.getContext("2d");

// Exibir palavra inicial
palavraDisplay.textContent = palavraCorreta.join(" ");

// Criar letras do alfabeto
for (let i = 65; i <= 90; i++) {
    const button = document.createElement("button");
    button.textContent = String.fromCharCode(i);
    button.addEventListener("click", letraEscolhida);
    letrasDiv.appendChild(button);
}

function letraEscolhida(event) {
    const letra = event.target.textContent.toLowerCase();
    event.target.disabled = true;

    if (palavra.includes(letra)) {
        palavra.split("").forEach((l, i) => {
            if (l === letra) palavraCorreta[i] = letra;
        });
        palavraDisplay.textContent = palavraCorreta.join(" ");
        if (!palavraCorreta.includes("_")) {
            mensagem.textContent = "🎉 Parabéns! Ganhou!";
        }
    } else {
        erros++;
        desenharForca(erros);
        if (erros >= maxErros) {
            mensagem.textContent = `💀 Perdeu! Palavra: ${palavra}`;
            letrasDiv.querySelectorAll("button").forEach(b => b.disabled = true);
        }
    }
}

// Função para desenhar a forca
function desenharForca(erros) {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.strokeStyle = "#f1faee";
    ctx.lineWidth = 2;

    // Base
    ctx.beginPath();
    ctx.moveTo(10, 240);
    ctx.lineTo(190, 240);
    ctx.stroke();

    // Poste
    ctx.beginPath();
    ctx.moveTo(50, 240);
    ctx.lineTo(50, 20);
    ctx.lineTo(150, 20);
    ctx.lineTo(150, 40);
    ctx.stroke();

    if (erros > 0) { // cabeça
        ctx.beginPath();
        ctx.arc(150, 60, 20, 0, Math.PI * 2);
        ctx.stroke();
    }
    if (erros > 1) { // corpo
        ctx.beginPath();
        ctx.moveTo(150, 80);
        ctx.lineTo(150, 150);
        ctx.stroke();
    }
    if (erros > 2) { // braço esquerdo
        ctx.beginPath();
        ctx.moveTo(150, 100);
        ctx.lineTo(120, 130);
        ctx.stroke();
    }
    if (erros > 3) { // braço direito
        ctx.beginPath();
        ctx.moveTo(150, 100);
        ctx.lineTo(180, 130);
        ctx.stroke();
    }
    if (erros > 4) { // perna esquerda
        ctx.beginPath();
        ctx.moveTo(150, 150);
        ctx.lineTo(120, 190);
        ctx.stroke();
    }
    if (erros > 5) { // perna direita
        ctx.beginPath();
        ctx.moveTo(150, 150);
        ctx.lineTo(180, 190);
        ctx.stroke();
    }
}
