"""Desenvolva uma aplicação gráfica que permite ao utilizador gerar passwords seguras.
A interface deve incluir um campo para se definir o comprimento da password, 
com um intervalo entre 8 e 16 caracteres, e checkboxes para selecionar os tipos de caracteres desejados, 
como letras maiusculas, minusculas, numeros e simbolos. 
Após definir os critérios, o utiilizador pode clicar num botão para gerar a password, 
que será exibida num campo de texto"""

'''from classes import * # Importação das funcoes criadas por nós'''
import tkinter as tk # Importação do tkinter
from tkinter import messagebox
from classes import principal
        
def main():
    principal()
    
if __name__ == "__main__":
    main()









