import tkinter as tk # Importação do tkinter
from random import choice

def principal():
    
    def copiar_password():
        import pyperclip
        from tkinter import messagebox
        
        copiado = mensagemlbl["text"]
        
        if copiado:
            pyperclip.copy(copiado)
            messagebox.showinfo("Sucesso", "Password copiada para a área de transferência!")
        else:
            messagebox.showwarning("Aviso", "Gere uma password primeiro!")
    
    def gerar_senha_segura(maiusculas, minusculas, numeros, simbolos, comprimento):
        import random
        import string
        from tkinter import messagebox
        
        # Dicionário com os caracteres de cada categoria
        categorias = {
            'maiusculas': string.ascii_uppercase if maiusculas else '',
            'minusculas': string.ascii_lowercase if minusculas else '',
            'numeros': string.digits if numeros else '',
            'simbolos': '!@#$%^&*' if simbolos else ''
        }
        
        # Remove categorias não selecionadas
        categorias = {k: v for k, v in categorias.items() if v}
        
        if not categorias:
            messagebox.showwarning("Aviso", "Não selecionou nenhuma opção!")
            return ""
        
        # Garante pelo menos um caractere de cada categoria selecionada
        senha = []
        for chars in categorias.values():
            senha.append(random.choice(chars))
        
        # Preenche o restante da senha com caracteres aleatórios de todas as categorias selecionadas
        todos_caracteres = ''.join(categorias.values())
        senha.extend(random.choice(todos_caracteres) for _ in range(int(comprimento) - len(senha)))
        
        # Embaralha a senha para não ter padrão previsível
        random.shuffle(senha)
        password_gerada = ''.join(senha)
        
        mensagemlbl.config(text=password_gerada, fg='green')
        return password_gerada
            
    def gerar_password():
        import random
        import string
        from tkinter import messagebox
              
        caracteres = ""
        
        try:
            comprimento = int(spinbox_input.get())
        except ValueError:
            messagebox.showwarning("Aviso", "O comprimento tem de ser numérico!")    
        else:         
            
            if comprimento > 16 or comprimento < 8:
                messagebox.showwarning("Aviso", "Tem de estar compreendido entre 8 e 16!")
                return ""  
                   
            maiusculas = maiusculas_checkbox.get()
            minusculas = minusculas_checkbox.get()
            numeros = numeros_checkbox.get()
            simbolos = simbolos_checkbox.get()     
               
            if maiusculas:
                caracteres += string.ascii_uppercase
            if minusculas:
                caracteres += string.ascii_lowercase
            if numeros:
                caracteres += string.digits
            if simbolos:
                caracteres += '!@#$%^&*'
                
            if caracteres != "":
                gerar_senha_segura(maiusculas, minusculas, numeros, simbolos, comprimento)
            else:
                messagebox.showwarning("Aviso", "Não selecionou nenhuma opção!")        

    
    # Janela principal
    janela = tk.Tk()
    '''janela.geometry("500x500")'''
    
    # Alterar titulo
    janela.title('Gerador de Passwords')
    
    spinbox_input = tk.StringVar()
    
    from tkinter import font
    
    font_pequena = font.Font(
    family="Arial",
    size=12,
    weight="bold"
    )
    
    font_grande = font.Font(
    family="Arial",
    size=15,
    weight="bold"
    )
    
    font_extra = font.Font(
    family="Arial",
    size=20,
    weight="bold"
    )
      
    font_titulo = font.Font(
    family="Arial",
    size=13,
    weight="bold"
    )
    
    # Configurar linhas e colunas para expansão
    janela.grid_rowconfigure(0, weight=1)
    janela.grid_columnconfigure(0, weight=1)
    
    # Frame principal
    main_frame = tk.Frame(janela)
    main_frame.grid(row=0, column=0)
    
    # Label com titulo
    mensagemlbl = tk.Label(main_frame, text='Nº DE CARACTERES ENTRE 8 A 16', font=font_titulo)
    mensagemlbl.grid(row=0, column=0, columnspan=2, pady=10)
    
    # Spinbox do comprimento de password
    tk.Spinbox(main_frame, text='', from_=8, to=16, increment=1, textvariable=spinbox_input, font=font_grande).grid(row=1, column=0, pady=10, sticky="NSEW")
    
    maiusculas_checkbox = tk.BooleanVar()
    minusculas_checkbox = tk.BooleanVar()
    numeros_checkbox = tk.BooleanVar()
    simbolos_checkbox = tk.BooleanVar()
        
    # Criando os checkboxes
    tk.Checkbutton(main_frame, text="Letras Maiúsculas (A-Z)", variable=maiusculas_checkbox, font=font_grande).grid(row=2, column=0, pady=10, sticky="NSEW")
    tk.Checkbutton(main_frame, text="Letras Minúsculas (a-z)", variable=minusculas_checkbox, font=font_grande).grid(row=3, column=0, pady=10, sticky="NSEW")
    tk.Checkbutton(main_frame, text="Números (0-9)", variable=numeros_checkbox, font=font_grande).grid(row=4, column=0, pady=10, sticky="NSEW")
    tk.Checkbutton(main_frame, text="Símbolos (!@#$%^&*)", variable=simbolos_checkbox, font=font_grande).grid(row=5, column=0, pady=10, sticky="NSEW")
    
    # Botão para gerar password
    mostrarbtn = tk.Button(main_frame, text='GERAR PASSWORD', width=10, command=gerar_password, font=font_pequena).grid(row=6, column=0, columnspan=2, pady=10, sticky="NSEW")

    # Label com password gerada
    mensagemlbl = tk.Label(main_frame, text='', font=font_extra)
    mensagemlbl.grid(row=7, column=0, columnspan=2)

    # Botão para copiar password gerada
    copiarbtn = tk.Button(main_frame, text='COPIAR PASSWORD', width=10, command=copiar_password, font=font_pequena).grid(row=8, column=0, columnspan=2, pady=10, sticky="NSEW")

    janela.mainloop()
