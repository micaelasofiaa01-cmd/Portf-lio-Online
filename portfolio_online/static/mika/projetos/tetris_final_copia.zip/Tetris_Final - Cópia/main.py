import pygame
from game import TetrisGame
from settings import SCREEN_WIDTH, SCREEN_HEIGHT

def main():
    pygame.init()
    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
    pygame.display.set_caption("Tetris")
    game = TetrisGame(screen)
    game.run()
    pygame.quit()

if __name__ == "__main__":
    main()

