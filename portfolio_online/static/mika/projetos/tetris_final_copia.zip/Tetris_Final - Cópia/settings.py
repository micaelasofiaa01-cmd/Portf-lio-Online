import pygame

pygame.init()

# ==============================
# ⚙️ DETETAR TAMANHO DO ECRÃ
# ==============================
info = pygame.display.Info()
SCREEN_W = info.current_w
SCREEN_H = info.current_h

# Ocupa até 90% da altura e 85% da largura do ecrã
TARGET_HEIGHT_RATIO = 0.9
TARGET_WIDTH_RATIO = 0.85

usable_width = int(SCREEN_W * TARGET_WIDTH_RATIO)
usable_height = int(SCREEN_H * TARGET_HEIGHT_RATIO)

# ======================================
# 🎨 TEMA NEON ARCADE
# ======================================
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
GRAY = (120, 120, 120)

NEON_CYAN = (0, 255, 255)
NEON_MAGENTA = (255, 0, 255)
NEON_GREEN = (57, 255, 20)
NEON_BLUE = (0, 200, 255)
NEON_PINK = (255, 20, 147)
NEON_YELLOW = (255, 255, 102)
NEON_ORANGE = (255, 140, 0)

BACKGROUND_TOP = (5, 5, 25)
BACKGROUND_BOTTOM = (30, 10, 50)
GRID_LINE = (35, 35, 60)
GRID_BORDER = (25, 25, 45)
BORDER_GLOW = NEON_CYAN
TEXT_COLOR = WHITE
SHADOW_COLOR = (40, 40, 80)

# ======================================
# ⚙️ CONFIGURAÇÕES DO JOGO
# ======================================
BOARD_WIDTH = 10
BOARD_HEIGHT = 20

LEFT_PANEL = 200
RIGHT_PANEL = 200
TOP_MARGIN = 80
BOTTOM_MARGIN = 80

# Calcular o tamanho máximo possível de bloco
max_block_height = (usable_height - (TOP_MARGIN + BOTTOM_MARGIN)) / BOARD_HEIGHT
max_block_width = (usable_width - (LEFT_PANEL + RIGHT_PANEL)) / BOARD_WIDTH
BLOCK_SIZE = int(min(max_block_width, max_block_height))

# Garantir tamanho mínimo para visibilidade
if BLOCK_SIZE < 15:
    BLOCK_SIZE = 15

# Calcular dimensões finais da janela
SCREEN_WIDTH = LEFT_PANEL + BOARD_WIDTH * BLOCK_SIZE + RIGHT_PANEL
SCREEN_HEIGHT = TOP_MARGIN + BOARD_HEIGHT * BLOCK_SIZE + BOTTOM_MARGIN

FALL_SPEED = 1000
LINE_SCORES = {
    1: 100,   # single
    2: 300,   # double
    3: 500,   # triple
    4: 800    # tetris
}

LINES_PER_LEVEL = 10

LEVEL_SPEED_MULTIPLIER = 0.85

COLORS = [
    NEON_CYAN, NEON_BLUE, NEON_ORANGE,
    NEON_YELLOW, NEON_GREEN, NEON_PINK, NEON_MAGENTA,
]







