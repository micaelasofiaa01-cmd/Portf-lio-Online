# board.py
from settings import BOARD_WIDTH, BOARD_HEIGHT, BLOCK_SIZE, BLACK, LINE_SCORES, LINES_PER_LEVEL
import pygame

class Board:
    def __init__(self):
        self.board = [[BLACK for _ in range(BOARD_WIDTH)] for _ in range(BOARD_HEIGHT)]
        self.score = 0
        self.level = 1
        self.lines_cleared_total = 0


    def valid_position(self, piece, adj_x=0, adj_y=0):
        for y, row in enumerate(piece.shape):
            for x, cell in enumerate(row):
                if cell:
                    new_x = piece.x + x + adj_x
                    new_y = piece.y + y + adj_y

                    # Out of horizontal bounds
                    if new_x < 0 or new_x >= BOARD_WIDTH:
                        return False

                    # If block below top row
                    if new_y >= BOARD_HEIGHT:
                        return False

                    # Check collision only if within visible board area
                    if new_y >= 0:
                        if self.board[new_y][new_x] != BLACK:
                            return False
                    # ✅ New check: if block is above top but directly over filled space
                    elif new_y < 0 and self.board[0][new_x] != BLACK:
                        return False
        return True

    
    def add_piece(self, piece):
        for y, row in enumerate(piece.shape):
            for x, cell in enumerate(row):
                if cell:
                    px = piece.x + x
                    py = piece.y + y
                    if py >= 0:
                        self.board[py][px] = piece.color
        # atualizar pontuação (linhas completas)
        self.clear_lines()

    def lock_piece(self, piece):
        for y, row in enumerate(piece.shape):
            for x, cell in enumerate(row):
                if cell and piece.y + y >= 0:
                    self.board[piece.y + y][piece.x + x] = piece.color
        self.clear_lines()

    def clear_lines(self):
        lines_cleared = 0
        new_board = []

        for row in self.board:
            if BLACK not in row:
                lines_cleared += 1
            else:
                new_board.append(row)

        while len(new_board) < BOARD_HEIGHT:
            new_board.insert(0, [BLACK] * BOARD_WIDTH)

        self.board = new_board

        if lines_cleared > 0:
            # Update score using LINE_SCORES dict
            self.score += LINE_SCORES.get(lines_cleared, 0) * self.level
            self.lines_cleared_total += lines_cleared

            # Level up every X lines
            if self.lines_cleared_total >= LINES_PER_LEVEL * self.level:
                self.level += 1


    def draw(self, screen, piece):
        # Desenha o tabuleiro
        for y in range(BOARD_HEIGHT):
            for x in range(BOARD_WIDTH):
                pygame.draw.rect(screen, self.board[y][x],
                                (x * BLOCK_SIZE, y * BLOCK_SIZE, BLOCK_SIZE, BLOCK_SIZE), 0)

        # Desenha a peça atual, mas só dentro dos limites do tabuleiro
        for y, row in enumerate(piece.shape):
            for x, cell in enumerate(row):
                if cell:
                    px = piece.x + x
                    py = piece.y + y
                    if 0 <= px < BOARD_WIDTH and 0 <= py < BOARD_HEIGHT:
                        pygame.draw.rect(screen, piece.color,
                                        (px * BLOCK_SIZE, py * BLOCK_SIZE, BLOCK_SIZE, BLOCK_SIZE), 0)

        # Desenha linhas da grade
        for x in range(BOARD_WIDTH + 1):
            pygame.draw.line(screen, (30, 30, 30), (x * BLOCK_SIZE, 0), (x * BLOCK_SIZE, BOARD_HEIGHT * BLOCK_SIZE))
        for y in range(BOARD_HEIGHT + 1):
            pygame.draw.line(screen, (30, 30, 30), (0, y * BLOCK_SIZE), (BOARD_WIDTH * BLOCK_SIZE, y * BLOCK_SIZE))

