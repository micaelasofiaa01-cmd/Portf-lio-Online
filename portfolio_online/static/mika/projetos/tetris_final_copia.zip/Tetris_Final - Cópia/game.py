import pygame
import random
import math
from board import Board
from tetromino import Tetromino
from settings import (
    BOARD_WIDTH, BOARD_HEIGHT, BLOCK_SIZE,
    SCREEN_WIDTH, SCREEN_HEIGHT, LEFT_PANEL, RIGHT_PANEL,
    FALL_SPEED, BLACK, TOP_MARGIN, WHITE, GRID_LINE,
    NEON_CYAN, NEON_BLUE, NEON_ORANGE, NEON_YELLOW,
    NEON_GREEN, NEON_PINK, NEON_MAGENTA, LINE_SCORES, LEVEL_SPEED_MULTIPLIER
)

class TetrisGame:
    def __init__(self, screen):
        self.screen = screen
        self.clock = pygame.time.Clock()
        self.board = Board()
        self.current_piece = Tetromino()
        self.next_piece = Tetromino()
        self.next_pieces = [Tetromino(), Tetromino()]  # next 2 pieces
        self.fall_time = 0
        self.is_game_over = False
        self.soft_drop = False

        self.board_x = LEFT_PANEL
        self.board_y = TOP_MARGIN
        
        self.best_score_file = "best_score.txt"
        self.best_score = self.load_best_score()

    def load_best_score(self):
        import os
        
        if os.path.exists(self.best_score_file):
            with open(self.best_score_file, "r") as f:
                try:
                    return int(f.read())
                except ValueError:
                    return 0
        else:
            return 0

    def save_best_score(self):
        with open(self.best_score_file, "w") as f:
            f.write(str(self.best_score))

    # Background animation stays same
    def draw_background(self):
        t = pygame.time.get_ticks() / 10
        for i in range(0, SCREEN_HEIGHT, 2):
            color = (
                10 + int(30 * abs(math.sin((i + t) * 0.01))),
                10 + int(60 * abs(math.cos((i + t) * 0.008))),
                30 + int(90 * abs(math.sin((i + t) * 0.009))),
            )
            pygame.draw.line(self.screen, color, (0, i), (SCREEN_WIDTH, i))

    
    def draw_left_panel(self):
        panel_rect = pygame.Rect(20, 80, LEFT_PANEL - 40, SCREEN_HEIGHT - 160)

        # 🖤 Background: solid black
        pygame.draw.rect(self.screen, BLACK, panel_rect, border_radius=8)

        # 💡 Neon blue border
        pygame.draw.rect(
            self.screen,
            (0, 180, 255),
            panel_rect,
            3,
            border_radius=8
        )

        # 🎨 Fonts (Comic Sans)
        font_label = pygame.font.SysFont('Comic Sans MS', 34, bold=True)
        font_value = pygame.font.SysFont('Comic Sans MS', 30)

        # 🧾 Prepare data (text and numbers all white)
        score_label = font_label.render("SCORE", True, WHITE)
        score_value = font_value.render(str(self.board.score), True, WHITE)

        level_label = font_label.render("LEVEL", True, WHITE)
        level_value = font_value.render(str(self.board.level), True, WHITE)

        # "BEST SCORE" split across two lines
        best_label_1 = font_label.render("BEST", True, WHITE)
        best_label_2 = font_label.render("SCORE", True, WHITE)
        best_value = font_value.render(str(self.best_score), True, WHITE)

        # 🧭 Calculate positions
        center_x = panel_rect.x + panel_rect.width // 2
        y = panel_rect.y + 80  # start lower for spacing

        # --- SCORE ---
        self.screen.blit(score_label, (center_x - score_label.get_width() // 2, y))
        y += score_label.get_height() + 5
        self.screen.blit(score_value, (center_x - score_value.get_width() // 2, y))
        y += score_value.get_height() + 40

        # --- LEVEL ---
        self.screen.blit(level_label, (center_x - level_label.get_width() // 2, y))
        y += level_label.get_height() + 5
        self.screen.blit(level_value, (center_x - level_value.get_width() // 2, y))
        y += level_value.get_height() + 60

        # --- BEST SCORE (two lines, slightly offset) ---
        best_y = y
        # "BEST" — slightly to the left
        self.screen.blit(best_label_1, (center_x - best_label_1.get_width() // 2 - 20, best_y))
        best_y += best_label_1.get_height() + 5
        # "SCORE" — slightly to the right
        self.screen.blit(best_label_2, (center_x - best_label_2.get_width() // 2 + 5, best_y))
        best_y += best_label_2.get_height() + 5

        # Centered best score value below
        self.screen.blit(best_value, (center_x - best_value.get_width() // 2, best_y))



    def draw_next_pieces(self):
        # Define panel rectangle
        panel_rect = pygame.Rect(
            LEFT_PANEL + BOARD_WIDTH * BLOCK_SIZE + 20, 80,
            RIGHT_PANEL - 40, SCREEN_HEIGHT - 160
        )

        # 🖤 Black background with rounded corners
        pygame.draw.rect(self.screen, BLACK, panel_rect, border_radius=8)

        # 💡 Neon blue border
        pygame.draw.rect(
            self.screen,
            (0, 180, 255),
            panel_rect,
            3,
            border_radius=8
        )

        # 🎨 Comic Sans font
        font_label = pygame.font.SysFont('Comic Sans MS', 28, bold=True)
        label = font_label.render("NEXT:", True, WHITE)

        # Center the "NEXT:" label horizontally
        label_x = panel_rect.x + (panel_rect.width - label.get_width()) // 2
        label_y = panel_rect.y + 10
        self.screen.blit(label, (label_x, label_y))

        # 🧮 Calculate total height of all pieces including spacing
        pieces = [self.next_piece] + self.next_pieces[0:2]
        piece_spacing = 40  # Increased spacing between pieces
        total_height = 0
        piece_heights = []

        for piece in pieces:
            h = len(piece.shape) * BLOCK_SIZE
            piece_heights.append(h)
            total_height += h
        total_height += piece_spacing * (len(pieces) - 1)

        # Starting Y position so that pieces are centered vertically in the panel
        start_y = label_y + label.get_height() + 10  # Closer to the label now
        panel_available_height = panel_rect.height - (label_y + label.get_height() + 10)
        start_y += (panel_available_height - total_height) // 2  # center vertically

        # Draw each piece
        current_y = start_y
        for idx, piece in enumerate(pieces):
            piece_height = piece_heights[idx]
            piece_width = len(piece.shape[0]) * BLOCK_SIZE
            offset_x = panel_rect.x + (panel_rect.width - piece_width) // 2  # center horizontally

            for y, row in enumerate(piece.shape):
                for x, cell in enumerate(row):
                    if cell:
                        rect = pygame.Rect(
                            offset_x + x * BLOCK_SIZE,
                            current_y + y * BLOCK_SIZE,
                            BLOCK_SIZE,
                            BLOCK_SIZE
                        )
                        pygame.draw.rect(self.screen, piece.color, rect)
                        pygame.draw.rect(self.screen, WHITE, rect, 1)

            current_y += piece_height + piece_spacing


    def draw_board(self, piece):
        # Use Board.draw() to draw board + current piece at (0,0)
        # But we want it at (self.board_x, self.board_y), so use surface offset:
        board_surface = pygame.Surface((BOARD_WIDTH * BLOCK_SIZE, BOARD_HEIGHT * BLOCK_SIZE))
        self.board.draw(board_surface, piece)
        self.screen.blit(board_surface, (self.board_x, self.board_y))

        # Draw neon border pulsating
        glow = 200 + int(55 * math.sin(pygame.time.get_ticks() * 0.005))
        pygame.draw.rect(
            self.screen,
            (0, glow, 255),
            (self.board_x - 4, self.board_y - 4,
             BOARD_WIDTH * BLOCK_SIZE + 8, BOARD_HEIGHT * BLOCK_SIZE + 8),
            3
        )

        # Draw grid lines over the board area
        for x in range(BOARD_WIDTH + 1):
            pygame.draw.line(
                self.screen, GRID_LINE,
                (self.board_x + x * BLOCK_SIZE, self.board_y),
                (self.board_x + x * BLOCK_SIZE, self.board_y + BOARD_HEIGHT * BLOCK_SIZE)
            )
        for y in range(BOARD_HEIGHT + 1):
            pygame.draw.line(
                self.screen, GRID_LINE,
                (self.board_x, self.board_y + y * BLOCK_SIZE),
                (self.board_x + BOARD_WIDTH * BLOCK_SIZE, self.board_y + y * BLOCK_SIZE)
            )

    def main_menu(self):
        running = True
        font = pygame.font.SysFont('Arial', 50, bold=True)
        while running:
            self.clock.tick(60)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    exit()
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_RETURN:
                        running = False

            self.draw_background()
            title = font.render("TETRIS", True, NEON_PINK)
            self.screen.blit(title, ((SCREEN_WIDTH - title.get_width()) // 2, 150))

            info_font = pygame.font.SysFont('Arial', 30)
            info = info_font.render("Press ENTER to Start", True, NEON_CYAN)
            self.screen.blit(info, ((SCREEN_WIDTH - info.get_width()) // 2, 300))

            pygame.display.update()
            
    def spawn_next_piece(self):
        self.current_piece = self.next_piece
        self.current_piece.x = (BOARD_WIDTH - len(self.current_piece.shape[0])) // 2
        self.current_piece.y = -len(self.current_piece.shape)  # ✅ keep this negative
        self.next_piece = self.next_pieces.pop(0)
        self.next_pieces.append(Tetromino())

        # 🔥 Important check
        if not self.board.valid_position(self.current_piece):
            self.is_game_over = True
            if self.game_over():
                self.reset_game()
            else:
                return False
        return True



    def game_over(self):
        font_big = pygame.font.SysFont('Arial', 60, bold=True)
        font_small = pygame.font.SysFont('Arial', 30)

        if self.board.score > self.best_score:
            self.best_score = self.board.score
            self.save_best_score()

        game_over_text = font_big.render("GAME OVER", True, NEON_PINK)
        restart_text = font_small.render("Press ENTER to Restart", True, NEON_CYAN)
        quit_text = font_small.render("Press ESC to Quit", True, NEON_YELLOW)

        waiting = True
        while waiting:
            self.clock.tick(60)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    exit()
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_RETURN:
                        return True
                    elif event.key == pygame.K_ESCAPE:
                        pygame.quit()
                        exit()

            self.draw_background()
            self.draw_left_panel()
            self.draw_board(self.current_piece)
            self.draw_next_pieces()

            overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
            overlay.set_alpha(180)
            overlay.fill((0, 0, 0))
            self.screen.blit(overlay, (0, 0))

            self.screen.blit(game_over_text, ((SCREEN_WIDTH - game_over_text.get_width()) // 2, 250))
            self.screen.blit(restart_text, ((SCREEN_WIDTH - restart_text.get_width()) // 2, 350))
            self.screen.blit(quit_text, ((SCREEN_WIDTH - quit_text.get_width()) // 2, 400))

            pygame.display.update()

    def reset_game(self):
        self.board = Board()
        self.current_piece = Tetromino()
        self.next_piece = Tetromino()
        self.next_pieces = [Tetromino(), Tetromino()]
        self.fall_time = 0
        self.is_game_over = False
        self.soft_drop = False
        self.screen.fill((0, 0, 0))
        self.draw_background()
        pygame.display.update()

    def run(self):
        self.main_menu()
        self.screen.fill((0, 0, 0))
        pygame.display.update()

        running = True
        
        while running:
            dt = self.clock.tick(60)
            self.fall_time += dt

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False

                if not self.is_game_over:
                    if event.type == pygame.KEYDOWN:
                        if event.key == pygame.K_LEFT:
                            self.current_piece.x -= 1
                            if not self.board.valid_position(self.current_piece):
                                self.current_piece.x += 1

                        elif event.key == pygame.K_RIGHT:
                            self.current_piece.x += 1
                            if not self.board.valid_position(self.current_piece):
                                self.current_piece.x -= 1

                        elif event.key == pygame.K_DOWN:
                            self.soft_drop = True   # ✅ start faster drop

                        elif event.key == pygame.K_UP:
                            self.current_piece.rotate()
                            if not self.board.valid_position(self.current_piece):
                                self.current_piece.x += 1
                                if not self.board.valid_position(self.current_piece):
                                    self.current_piece.x -= 2
                                    if not self.board.valid_position(self.current_piece):
                                        self.current_piece.x += 1
                                        for _ in range(3):
                                            self.current_piece.rotate()

                    elif event.type == pygame.KEYUP:
                        if event.key == pygame.K_DOWN:
                            self.soft_drop = False  # ✅ stop faster drop


            fall_speed = int(FALL_SPEED * (LEVEL_SPEED_MULTIPLIER ** (self.board.level - 1)))
            fall_speed = max(fall_speed, 100)  # never faster than 0.1s per fall

            if self.soft_drop:
                fall_speed //= 8

            if not self.is_game_over and self.fall_time > fall_speed:
                self.fall_time = 0
                self.current_piece.y += 1
                if not self.board.valid_position(self.current_piece):
                    self.current_piece.y -= 1
                    self.board.add_piece(self.current_piece)
                    self.spawn_next_piece()

                    if not self.board.valid_position(self.current_piece):
                        self.is_game_over = True
                        if self.game_over():
                            self.reset_game()
                        else:
                            running = False

            self.draw_background()
            self.draw_left_panel()
            self.draw_board(self.current_piece)
            self.draw_next_pieces()
            pygame.display.update()