# menu.py
import pygame
from settings import SCREEN_WIDTH, SCREEN_HEIGHT, NEON_BLUE, NEON_PINK, NEON_GREEN, BLACK, WHITE

def main_menu(screen):
    title_font = pygame.font.SysFont("comicsansms", 80, bold=True)
    small_font = pygame.font.SysFont("comicsansms", 32)
    clock = pygame.time.Clock()
    running = True
    color_shift = 0

    while running:
        color_shift = (color_shift + 3) % 360
        screen.fill(BLACK)

        # título com efeito neon animado
        title = title_font.render("TETRIS", True, (abs(255 - color_shift) % 255, 100, 255))
        start = small_font.render("Press ENTER to Start", True, NEON_GREEN)
        quit_text = small_font.render("Press ESC to Quit", True, WHITE)

        screen.blit(title, (SCREEN_WIDTH//2 - title.get_width()//2, 230))
        screen.blit(start, (SCREEN_WIDTH//2 - start.get_width()//2, 360))
        screen.blit(quit_text, (SCREEN_WIDTH//2 - quit_text.get_width()//2, 410))

        pygame.display.update()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN:
                    return True
                elif event.key == pygame.K_ESCAPE:
                    return False
        clock.tick(30)
